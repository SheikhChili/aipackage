ML Automation

This is an ml automation project that is used to automate the ML process and DL process


   pip install example-publish-pypi-medium

Usage

>>> from src.example import custom_sklearn
>>> custom_sklearn.get_sklearn_version()
'0.24.2'